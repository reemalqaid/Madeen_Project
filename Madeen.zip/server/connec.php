<?php
$dbHost="localhost";
$dbUser="root";
$dbPass="";
$dbName="madeen";
$conn = new PDO("mysql:host=$dbHost;dbname=$dbName",$dbUser,$dbPass);

 ?>
